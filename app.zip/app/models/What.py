
from system.core.model import Model

class What(Model):
	def __init__(self):
		super(What, self).__init__()

	def create_users(self, users):
		query = 'INSERT INTO users (name, phone, password) VALUES (%s,%s,%s)'
		data =[users['name'], users['number'], users['password']]

		return self.db.query_db(query,data)

	def get_events(self):
		query= 'select * from users  join events on events.user_id = users.id'
		return self.db.query_db(query)

