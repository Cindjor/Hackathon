
from system.core.controller import *
import json
class Whats(Controller):
	def __init__(self, action):
		super(Whats, self).__init__(action)
		self.load_model('What')
	def index(self):  
		categories=self.getValueCategory()

		return self.load_view('index.html',categories=categories)

	def index1(self):  
		categories=self.getValueCategory()

		return self.load_view('deepa.html',categories=categories)

	def getValueCategory(self):
		category=[]
		url = "http://api.eventful.com/json/categories/list?app_key=jk5zHMNmqkqjb6jS"
		
		res = json.loads(requests.get(url).content)

		for dictvalue in res["category"]:
			category.append({"id": dictvalue["id"], "name":dictvalue["name"].replace('&amp;','&')})
		
		return category

	def getallgeocode(self):
		url="http://api.eventful.com/json/events/search?app_key=jk5zHMNmqkqjb6jS&location=san%20jose,%20CA&page_size=10"
		res = requests.get(url).content
		return res

	def getcategorygeocode(self,categoryid):
		url="http://api.eventful.com/json/events/search?app_key=jk5zHMNmqkqjb6jS&location=san%20jose,%20CA&page_size=20"


		url+=str(categoryid)
		res = requests.get(url).content
		return jsonify(res=res)

	def event(self):
		events= self.models['What'].get_events()
		return self.load_view('events.html', events=events)

	def create_user(self):
		users = {'name' : request.form['name'],'number' : request.form['number'],'password' : request.form['pwd']}
		self.models['What'].create_users(users)
		return redirect ('/home')
	def home(self):

		return self.load_view('home.html')
